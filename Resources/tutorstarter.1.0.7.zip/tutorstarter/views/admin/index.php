<?php
/**
 * Template part for displaying a custom Admin area
 *
 * @link https://developer.wordpress.org/reference/functions/add_menu_page/
 *
 * @package Tutor_Starter
 */

defined( 'ABSPATH' ) || exit;
// Silence is golden.
