

<textarea name="tutor_withdraw_options[<?php esc_attr_e( $method_id ); ?>][<?php esc_attr_e( $field_name ); ?>]"><?php esc_html_e( $saved_value ); ?></textarea>