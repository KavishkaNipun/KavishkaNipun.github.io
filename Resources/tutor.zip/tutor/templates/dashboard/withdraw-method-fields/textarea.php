<?php
/**
 * @package TutorLMS/Templates
 * @version 1.4.3
 */

?>
<textarea name="withdraw_method_field[<?php echo esc_attr( $method_id ); ?>][<?php echo esc_attr( $field_name ); ?>]"><?php echo esc_attr( $old_value ); ?></textarea>
